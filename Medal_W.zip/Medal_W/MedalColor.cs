namespace Medal_W;

public enum MedalColor
{
	Bronze,
	Silver,
	Gold
}
