namespace Lab_08_Time;

public enum TimeFormat
{
	Mil,
	Hour12,
	Hour24
}


