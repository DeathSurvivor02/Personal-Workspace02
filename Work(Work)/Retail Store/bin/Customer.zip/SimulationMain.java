public class SimulationMain
{
	public static void main(String args[]){
		RetailStore store = new RetailStore();
		
		store.run();
	}
}