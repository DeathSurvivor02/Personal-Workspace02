int i = 0;

i.length();