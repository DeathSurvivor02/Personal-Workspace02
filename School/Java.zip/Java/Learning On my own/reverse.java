package School.Java.Learning On my own;

public class reverse {

	int grid[][] = 0;

	public void Reverse(int rowNum, int start)
	{
		int temp;
		/* 
		 * Step 1:
		 *		find the number it is starting at.
		 *Step 2: 
		 * 		temp file
		 * step 3: 
		 * 		store first location into temp 
		 * step 4
		 * 		store last location into first
		 * step 5
		 * 		store temp into last
		 * step 6
		 * 		repeat step 1 to 5
		 *  
		 */

		temp = grid[rowNum][start];
		grid[rowNum][start] = grid[rowNum][columns];
		grid
	}
	
}

