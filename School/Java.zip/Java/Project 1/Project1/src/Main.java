// package.IcodeEan;

public class Main
{
	public void main(String[] args) {
		// String name = "";
		System.out.println("Hello My name is Ean.\n");
		System.out.println("What is your name?\n");
		// System.in.read(name);
	}
}