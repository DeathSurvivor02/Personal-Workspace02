	private int rows = 10;
	private int columns = 10;
	private int temp;
	private int grid[][];
	private float muRow;
	private float muCol;

	// private int sum;
	private double sigmaTotalRow;
	private double sigmaTotalCol;
	private int sumRow = 0;
	private int sumCol= 0;
	private double sigmaRow = 0.0f;
	private double sigmaCol = 0.0f;
	
	private int rowData[]; //todo
	private int colData[]; //todo
	