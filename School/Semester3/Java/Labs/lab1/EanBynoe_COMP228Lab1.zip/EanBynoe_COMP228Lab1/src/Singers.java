
public class Singers {

  //    variable declarations
  int id;
  String name;
  String address;
  String dateOfBirth;
  int numberOfAlbums;

  //    Constructors
  Singers(
    int id,
    String name,
    String address,
    String dateOfBirth,
    int numberOfAlbums
  ) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.dateOfBirth = dateOfBirth;
  }

  Singers() {}

  //    getters
  public int getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String getAddress() {
    return address;
  }

  public String getDateofBirth() {
    return dateOfBirth;
  }

  public int getNumberOfAlbums() {
    return numberOfAlbums;
  }

  //    setters
  public void setId(int id) {
    this.id = id;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public void setDateOfBirth(String dateOfBirth) {
    this.dateOfBirth = dateOfBirth;
  }

  public void setNumberOfAlbums(int numberOfAlbums) {
    this.numberOfAlbums = numberOfAlbums;
  }

  public void setAll(
    int id,
    String name,
    String address,
    String dateOfBirth,
    int numberOfAlbums
  ) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.dateOfBirth = dateOfBirth;
    this.numberOfAlbums = numberOfAlbums;
  }
}
