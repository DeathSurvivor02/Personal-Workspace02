public class Main {

  public static void main(String[] args) {
    //    Default values
    Singers singer1 = new Singers();
    System.out.println(
      "Singer id: " +
      singer1.getId() +
      "\nSinger name: " +
      singer1.getName() +
      "\nSinger Address: " +
      singer1.getAddress() +
      "\nSinger Date of Birth: " +
      singer1.getDateofBirth() +
      "\nSinger Albums: " +
      singer1.getNumberOfAlbums()
    );

    //    Cluster input
    Singers singer3 = new Singers();
    singer3.setAll(3, "Ean Bynoe", "Fair View Christ Church", "2002-10-09", 4);
    System.out.println(
      "Singer id: " +
      singer3.getId() +
      "\nSinger name: " +
      singer3.getName() +
      "\nSinger Address: " +
      singer3.getAddress() +
      "\nSinger Date of Birth: " +
      singer3.getDateofBirth() +
      "\nSinger Albums: " +
      singer3.getNumberOfAlbums()
    );

    //    Single input
    Singers singer2 = new Singers();
    singer2.setId(2);
    singer2.setName("21 Savage");
    singer2.setAddress("Savage Street");
    singer2.setDateOfBirth("1992-10-22");
    singer2.setNumberOfAlbums(16);
    System.out.println(
      "Singer id: " +
      singer2.getId() +
      "\nSinger name: " +
      singer2.getName() +
      "\nSinger Address: " +
      singer2.getAddress() +
      "\nSinger Date of Birth: " +
      singer2.getDateofBirth() +
      "\nSinger Albums: " +
      singer2.getNumberOfAlbums()
    );
  }
}
