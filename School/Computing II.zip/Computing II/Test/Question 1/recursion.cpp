#include <iostream>

void sumsquared(int n);
int main()
{
	sumsquared()
}
int sumsquared(int n) {
    if (n == 1) {
        return n;
    }
    else {

        return (n*n) + sum(n-1);

    }

};