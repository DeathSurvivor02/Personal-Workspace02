// #include <iostream>

// int sum(int n);
// int main()
// {
// 	int val;
// 	std::cin >> val;
// 	std::cout << sum(val);
// 	return 0;
// }

// int sum(int n)
// {
// 	int val;
// 	if (n < 0)
// 	{
// 		// std::cout << val;
// 		return val;
// 	}
// 	else 
// 	{
// 		return val = n + sum(n-1);
// 	}
// }

#include <iostream>

int main()
{
	float num;
	num = 0.01 + 0.02;
	std::cout << num << std::endl;
	return 0;
}