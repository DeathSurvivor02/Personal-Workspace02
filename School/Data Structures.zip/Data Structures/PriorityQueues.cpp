#ifndef PQUEUE_H
#define PQUEUE_H

int 
class name
{
	string name 
};