#ifndef __Queue__H
#define __Queue__H

#include <iostream>

class PQueue
{
	private:
		Node *head;
		Node *tail;
	public:
		PQueue();
		void en
}



#endif