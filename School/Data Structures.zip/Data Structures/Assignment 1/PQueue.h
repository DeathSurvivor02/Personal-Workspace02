#ifndef __PQueue__H
#define __PQueue__H

#include <iostream>
using namespace std;

class PQueue
{
	private:
		Node *head;
		Node *tail;
	public:
	
};



#endif