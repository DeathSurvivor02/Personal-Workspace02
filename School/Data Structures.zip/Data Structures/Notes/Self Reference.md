[cpp]
<!-- // Sample code -->

[class Node
{
	private:
		int data;
		Node *nextPtr;
	public:
		Node(int);
		void setData(int);
		int getData() const;
		void setNextPtr(Node *);
		Node *getNextPtr() const;
};]
