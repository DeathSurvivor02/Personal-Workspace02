INSERT INTO production_categories(category_id,category_name) VALUES(1,'Children Bicycles');
INSERT INTO production_categories(category_id,category_name) VALUES(2,'Comfort Bicycles');
INSERT INTO production_categories(category_id,category_name) VALUES(3,'Cruisers Bicycles');
INSERT INTO production_categories(category_id,category_name) VALUES(4,'Cyclocross Bicycles');
INSERT INTO production_categories(category_id,category_name) VALUES(5,'Electric Bikes');
INSERT INTO production_categories(category_id,category_name) VALUES(6,'Mountain Bikes');
INSERT INTO production_categories(category_id,category_name) VALUES(7,'Road Bikes');