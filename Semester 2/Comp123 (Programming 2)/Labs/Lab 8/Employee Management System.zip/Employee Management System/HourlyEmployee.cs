using System;

namespace Employee_Management_System;

public class HourlyEmployee
{

}
