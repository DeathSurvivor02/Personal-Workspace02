using System;

namespace Employee_Management_System;

public interface IPlayable_Interface
{
	double CalculateSalary();
}
