using System;

namespace Employee_Management_System;

public interface IReportable_Interface
{
	void GeneratqReport();}
