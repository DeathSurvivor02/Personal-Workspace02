using System;

namespace Employee_Management_System;

public class Employee_Class
{
	string name;
	int id;
	string department;


	Employee_Class(string name, int id, string department)
	{
		this.name = name;
		this.id = id;
		this.department = department;
	}

	
}
