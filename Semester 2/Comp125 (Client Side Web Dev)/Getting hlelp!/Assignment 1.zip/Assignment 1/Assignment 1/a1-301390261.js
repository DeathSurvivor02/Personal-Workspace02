document.querySelector('[type="button"]').addEventListener('click', e=>{

    let Bal = document.getElementById("Bal").value;
    let Inter = document.getElementById("Int").value;
    let Yrs = document.getElementById("Yrs").value;

   let percent = Inter / 100
   let TotalInterest = Bal * percent
   let IntBal = Bal * percent * Yrs

    document.getElementById("TotalInterest").innerHTML = "$" + TotalInterest
    document.getElementById("TotalBalance").innerHTML = "$" + IntBal
});
