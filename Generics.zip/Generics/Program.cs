﻿class Program
{
    static void Main()
    {
        Console.WriteLine("Testing stack with integers:");
        TestIntStack();

        Console.WriteLine("\n\nTesting stack with strings:");
        TestStringStack();
    }

    static void TestIntStack()
    {
        GenericStack<int> stack = new GenericStack<int>();
        Console.WriteLine("Pushing 0 to 14 onto the stack...");
        
        for (int i = 0; i < 15; i++)
        {
            stack.Push(i);
        }

        Console.WriteLine("Popping elements from the stack:");
        while (!stack.IsEmpty)
        {
            Console.Write($"{stack.Pop()} ");
        }
    }

    static void TestStringStack()
    {
        GenericStack<string> stack = new GenericStack<string>();
        Console.WriteLine("Pushing 'A', 'B', 'C', 'D', 'E' onto the stack...");

        stack.Push("A");
        stack.Push("B");
        stack.Push("C");
        stack.Push("D");
        stack.Push("E");

        Console.WriteLine("Popping elements from the stack:");
        while (!stack.IsEmpty)
        {
            Console.Write($"{stack.Pop()} ");
        }
    }
}
